# 🎓 Student Success AI
### A beginner-friendly Machine Learning project by Utsav Upadhyay

Predict whether a student is likely to pass using study hours, attendance, and assignment score — then explore patterns in a simple interactive dashboard.

> **Learning project notice:** The included dataset is synthetic and generated for demonstration. This project is not validated for real academic decisions and should not be used to label or judge real students.

## ✨ Features
- Interactive Streamlit dashboard
- Data exploration and visual summaries
- Scikit-learn classification pipeline
- Pass probability estimate from three inputs
- Model evaluation with accuracy and confusion matrix
- Clear beginner-friendly code and reproducible setup

## 🧰 Tech Stack
Python · Pandas · NumPy · Matplotlib · Seaborn · Scikit-learn · Streamlit · Git/GitHub

## 📁 Project Structure
```text
student-success-ai/
├── app.py
├── train_model.py
├── requirements.txt
├── README.md
├── .gitignore
└── data/
    └── student_performance.csv
```

## 🚀 Run it locally
1. Install Python 3.10 or newer.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Start the app:
   ```bash
   streamlit run app.py
   ```

The app trains the model from the included sample data when it starts, so you do not need to download a separate model file.

## 📊 How it works
1. Load the sample dataset with Pandas.
2. Split the data into training and testing sets.
3. Train a Logistic Regression classification model using a scikit-learn pipeline.
4. Evaluate the model on a held-out test set.
5. Use the dashboard to explore the data and request a demonstration prediction.

## 🧠 Inputs
- **Study hours/day:** average daily study time
- **Attendance (%):** attendance percentage
- **Assignment score:** score out of 100

The dataset also contains a synthetic exam score and a pass/fail label. The model learns patterns in this generated data; results are only a coding demonstration.

## 🔬 What I learned
- Reading and exploring CSV data
- Separating features and target labels
- Train/test split and model evaluation
- Classification and predicted probabilities
- Building a basic data app with Streamlit
- Organizing a project for GitHub

## 🗺️ Future improvements
- Replace synthetic data with an appropriately consented, real dataset
- Compare multiple models and use cross-validation
- Add model explainability and calibration checks
- Improve accessibility and add tests
- Deploy the app after reviewing privacy and fairness risks

## 👋 About the author
**Utsav Upadhyay**  
BCA student specializing in Artificial Intelligence & Machine Learning at Galgotias University.

I'm learning Python, data analysis, and machine learning by building practical projects. This is my first portfolio project, and I plan to keep improving it as I learn.

**Learning today, building tomorrow.** 🚀
