from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import streamlit as st
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

st.set_page_config(
    page_title="Student Success AI",
    page_icon="🎓",
    layout="wide",
)

DATA_PATH = Path(__file__).parent / "data" / "student_performance.csv"
FEATURES = ["study_hours_per_day", "attendance_percent", "assignment_score"]
TARGET = "passed"

@st.cache_data
def load_data():
    return pd.read_csv(DATA_PATH)

@st.cache_resource
def train_model(data):
    X = data[FEATURES]
    y = data[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    model = Pipeline([
        ("scale", StandardScaler()),
        ("classifier", LogisticRegression(max_iter=1000, random_state=42)),
    ])
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    return model, accuracy_score(y_test, y_pred), confusion_matrix(y_test, y_pred)

data = load_data()
model, accuracy, matrix = train_model(data)

st.title("🎓 Student Success AI")
st.markdown("### Explore student learning patterns with a beginner-friendly ML demo")
st.caption("Built by Utsav Upadhyay · BCA AI & ML student")

st.warning(
    "Educational demo only: this project uses synthetic, computer-generated data. "
    "Predictions are not validated and must not be used for real academic decisions."
)

m1, m2, m3, m4 = st.columns(4)
m1.metric("Sample records", f"{len(data):,}")
m2.metric("Features used", len(FEATURES))
m3.metric("Demo test accuracy", f"{accuracy:.0%}")
m4.metric("Pass rate in sample", f"{data[TARGET].mean():.0%}")

tab1, tab2, tab3 = st.tabs(["📊 Explore data", "🔎 Try a demo prediction", "🧪 Model notes"])

with tab1:
    st.subheader("A quick look at the sample dataset")
    st.dataframe(data.head(12), use_container_width=True)
    left, right = st.columns(2)
    with left:
        fig, ax = plt.subplots()
        sns.scatterplot(
            data=data, x="study_hours_per_day", y="exam_score",
            hue="passed", palette="Set2", alpha=0.75, ax=ax
        )
        ax.set_title("Study hours vs. synthetic exam score")
        ax.set_xlabel("Study hours per day")
        ax.set_ylabel("Synthetic exam score")
        st.pyplot(fig)
        plt.close(fig)
    with right:
        fig, ax = plt.subplots()
        sns.histplot(data=data, x="attendance_percent", hue="passed", bins=15,
                     multiple="stack", ax=ax)
        ax.set_title("Attendance distribution in sample data")
        ax.set_xlabel("Attendance (%)")
        st.pyplot(fig)
        plt.close(fig)

with tab2:
    st.subheader("Try the model")
    st.write("Change the example inputs and see the model's estimated class probabilities.")
    c1, c2, c3 = st.columns(3)
    with c1:
        hours = st.slider("Study hours per day", 0.0, 10.0, 4.0, 0.5)
    with c2:
        attendance = st.slider("Attendance (%)", 40, 100, 75)
    with c3:
        assignment = st.slider("Assignment score (out of 100)", 20, 100, 70)
    if st.button("Estimate demo probability", type="primary"):
        sample = pd.DataFrame([{
            "study_hours_per_day": hours,
            "attendance_percent": attendance,
            "assignment_score": assignment,
        }])
        probabilities = model.predict_proba(sample)[0]
        pass_probability = float(probabilities[1])
        st.metric("Estimated pass probability (demo)", f"{pass_probability:.1%}")
        st.progress(pass_probability)
        st.info(
            "This is a model output from synthetic data, not a reliable prediction "
            "about any real student's future. Many factors are not included."
        )

with tab3:
    st.subheader("How this demo works")
    st.markdown("""
    1. **Pandas** loads and organizes the CSV data.
    2. **Scikit-learn** splits the data into training and test sets.
    3. A **StandardScaler + Logistic Regression** pipeline learns a classification pattern.
    4. The model is evaluated on a held-out test set.
    5. The dashboard displays basic visualizations and sample predictions.

    **Features:** study hours, attendance, and assignment score.  
    **Target:** a synthetic pass/fail label.  
    **Evaluation:** test accuracy and confusion matrix.  
    **Limitations:** synthetic data can create misleadingly neat patterns; this is a learning
    project, not an educational assessment product.
    """)
    st.write("Confusion matrix (rows = actual class; columns = predicted class)")
    st.dataframe(pd.DataFrame(matrix, index=["Actual fail", "Actual pass"],
                              columns=["Predicted fail", "Predicted pass"]))
    st.caption("Accuracy is shown for learning purposes and is not evidence of real-world validity.")
