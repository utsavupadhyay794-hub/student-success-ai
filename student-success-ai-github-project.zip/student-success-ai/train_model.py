"""Train and evaluate the Student Success AI demo classifier."""
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

DATA_PATH = Path(__file__).parent / "data" / "student_performance.csv"
FEATURES = ["study_hours_per_day", "attendance_percent", "assignment_score"]
TARGET = "passed"


def load_data():
    data = pd.read_csv(DATA_PATH)
    return data[FEATURES], data[TARGET]


def main():
    X, y = load_data()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    model = Pipeline([
        ("scale", StandardScaler()),
        ("classifier", LogisticRegression(max_iter=1000, random_state=42)),
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    print("STUDENT SUCCESS AI — DEMO MODEL")
    print(f"Test accuracy: {accuracy_score(y_test, predictions):.3f}")
    print("\nConfusion matrix:\n", confusion_matrix(y_test, predictions))
    print("\nClassification report:\n", classification_report(y_test, predictions))
    print("\nReminder: results are based on synthetic demonstration data.")


if __name__ == "__main__":
    main()
